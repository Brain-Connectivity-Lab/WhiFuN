function [all_ts,n_gm,n_wm,n_deep_wm,n_csf] = whifun_ts_extract(GM_mask_path,WM_mask_path,deep_WM_mask_path,CSF_mask_path,func_path,pre_,over_write,thresh_gm,thresh_wm,thresh_deep_wm,thresh_csf)

if ~exist("thresh_gm",'var')
    thresh_gm = 0.5;
end

if ~exist("thresh_wm",'var')
    thresh_wm = 0.5;
end

if ~exist("thresh_deep_wm",'var')
    thresh_deep_wm = 0.5;
end

if ~exist("thresh_csf",'var')
    thresh_csf = 0.5;
end


if create_mask(over_write,func_path,[pre_ 'GM_Mask_for_ts_qc'],thresh_gm)
    whifun_create_mask(GM_mask_path,func_path,thresh_gm,[pre_ 'GM_Mask_for_ts_qc']);
end
if create_mask(over_write,func_path,[pre_ 'WM_Mask_for_ts_qc'],thresh_wm)
    whifun_create_mask(WM_mask_path,func_path,thresh_wm,[pre_ 'WM_Mask_for_ts_qc']);
end
if create_mask(over_write,func_path,[pre_ 'deep_WM_Mask_for_ts_qc'],thresh_deep_wm)
    whifun_create_mask(deep_WM_mask_path,func_path,thresh_deep_wm,[pre_ 'deep_WM_Mask_for_ts_qc']);
end
if create_mask(over_write,func_path,[pre_ 'CSF_Mask_for_ts_qc'],thresh_csf)
    whifun_create_mask(CSF_mask_path,func_path,thresh_csf,[pre_ 'CSF_Mask_for_ts_qc']);
end

% output = [output_gm,output_wm,output_deep_wm,output_csf];

%% Extract TS
func_image = niftiread(func_path);

[~,~,~,T] = size(func_image);

func_image = reshape(func_image,[],T);
now_func_path = dir(func_path);
[gm_ts, n_gm] = extract_ts(func_image,fullfile(now_func_path.folder,[pre_ 'GM_Mask_for_ts_qc' '_' num2str(thresh_gm) '.nii']));
[wm_ts,n_wm,n_deep_wm] = extract_ts_wm(func_image,fullfile(now_func_path.folder,[pre_ 'WM_Mask_for_ts_qc'  '_' num2str(thresh_wm) '.nii']),fullfile(now_func_path.folder,[pre_ 'deep_WM_Mask_for_ts_qc' '_' num2str(thresh_deep_wm) '.nii']));
[csf_ts,n_csf] = extract_ts(func_image,fullfile(now_func_path.folder,[pre_ 'CSF_Mask_for_ts_qc' '_' num2str(thresh_csf) '.nii']));

all_ts =    [gm_ts
             wm_ts
             csf_ts];

end


function output = whifun_create_mask(mask,func_path,thresh_,mask_name)
now_mask_path = dir(mask);
now_func_path = dir(func_path);
matlabbatch{1}.spm.util.imcalc.input = {
    [fullfile(now_func_path.folder,now_func_path.name),',1']
    fullfile(now_mask_path.folder,now_mask_path.name)
    };
matlabbatch{1}.spm.util.imcalc.output = [mask_name '_' num2str(thresh_) '.nii'];
matlabbatch{1}.spm.util.imcalc.outdir = {now_func_path(1).folder};
matlabbatch{1}.spm.util.imcalc.expression = ['i2>' num2str(thresh_)];
matlabbatch{1}.spm.util.imcalc.var = struct('name', {}, 'value', {});
matlabbatch{1}.spm.util.imcalc.options.dmtx = 0;
matlabbatch{1}.spm.util.imcalc.options.mask = 0;
matlabbatch{1}.spm.util.imcalc.options.interp = 1;
matlabbatch{1}.spm.util.imcalc.options.dtype = 4;

spm('defaults', 'FMRI');
spm_jobman('initcfg');

% Suppress GUI
spm_get_defaults('cmdline', true);
output = evalc("spm_jobman('run',matlabbatch)");
end

function [ts,n] = extract_ts(func_image,mask_path)

mask_image = niftiread(mask_path);
mask_image = reshape(mask_image, [], 1);
ts = func_image(mask_image > 0, :);
n = size(ts,1);
end

function [wm_ts, n_wm, n_deep_wm] = extract_ts_wm(func_image,wm_mask_path,deep_wm_mask_path)
    wm_mask_image = logical(niftiread(wm_mask_path));
    deep_wm_image = logical(niftiread(deep_wm_mask_path));
    other_wm = wm_mask_image & ~deep_wm_image;

    other_wm_ts = func_image(other_wm > 0,:);
    deep_wm_ts = func_image(deep_wm_image>0,:);

    n_wm = size(other_wm_ts,1);
    n_deep_wm = size(deep_wm_ts,1);
    wm_ts = [other_wm_ts; deep_wm_ts]; % Combine time series from other WM regions
end

function out = create_mask(over_write,func_path,mask_name,thresh_)

if over_write
    out = [];
else
    now_func_path = dir(func_path);
    out = dir(fullfile(now_func_path.folder,[mask_name '_' num2str(thresh_) '.nii']));
end
if ~isempty(out)
    out = 0;
else
    out = 1;
end
end